#!/bin/bash

sudo ./Judge -l 2 -D data/1317 -d temp -t 200 -m 65535 -o 81920


